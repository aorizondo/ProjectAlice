_snips-asr() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            snips-asr)
                cmd="snips-asr"
                ;;
            
            file)
                cmd+="__file"
                ;;
            help)
                cmd+="__help"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        snips-asr)
            opts=" -v -h -V -m -c -a -u  --no_snips_audio_server_replay --no_warmup --use-final-probs --partial --verbose --color --no-color --no-exit-on-all-panics --mqtt-tls-disable-root-store --help --version --model --thread_number --beam-size --min-active --max-active --lattice-beam-size --acoustic-scale --endpointing --partial-period-ms --config --bus --mqtt --mqtt-username --mqtt-password --mqtt-tls-hostname --mqtt-tls-cafile --mqtt-tls-capath --mqtt-tls-client-cert --mqtt-tls-client-key --audio --assistant --user-dir   file help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --model)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -m)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --thread_number)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --beam-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --min-active)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --max-active)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --lattice-beam-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --acoustic-scale)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --endpointing)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --partial-period-ms)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bus)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-username)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-hostname)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-cafile)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-capath)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --audio)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --assistant)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -a)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --user-dir)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -u)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
        snips__asr__file)
            opts=" -h -V  --endpointing --realtime --help --version --loops  <WAV_FILE>... "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --loops)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        snips__asr__help)
            opts=" -h -V  --help --version  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

complete -F _snips-asr -o bashdefault -o default snips-asr
